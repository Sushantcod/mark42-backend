// GFG scraper template
module.exports = { async scrapeGFG(username){ return { platform:'gfg', username } } };
